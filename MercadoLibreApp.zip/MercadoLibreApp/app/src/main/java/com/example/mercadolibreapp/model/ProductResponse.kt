package com.example.mercadolibreapp.model

data class ProductResponse(
    val results: List<Product>
)
